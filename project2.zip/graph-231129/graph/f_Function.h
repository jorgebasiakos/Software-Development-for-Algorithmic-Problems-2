#ifndef F_FUNCTION_H
#define F_FUNCTION_H
#include <random>
#include <unordered_map>
#include "hashFunction.h"

class F_Function
{
public:
    HashFunction hash_function;
    std::unordered_map<int, char> f_mappings;
    int dimension;
    int w;

    F_Function(int _dimension, int _w);
    char calc_zero_or_one(Image* img);
};

#endif //F_FUNCTION_H