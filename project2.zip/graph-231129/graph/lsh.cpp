#include "lsh.h"

LSH::LSH(vector<Image*>& data, int _table_count, int _h_function_count, int _dimension, int _w, int _hash_table_divisor)
{
    table_count = _table_count;
    h_function_count = _h_function_count;
    dimension = _dimension;
    hash_table_divisor = _hash_table_divisor;
    w = _w;

    for (int i = 0; i < table_count; i++)
    {
        //create hash tables
        hash_tables.push_back(HashTable(data, dimension, h_function_count, w, hash_table_divisor));
    }

}
