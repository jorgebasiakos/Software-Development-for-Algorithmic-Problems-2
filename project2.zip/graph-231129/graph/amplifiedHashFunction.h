#ifndef AMPLIFIED_H
#define AMPLIFIED_H
#include <vector>
#include <cmath>
#include <random>
#include <climits>
#include "hashFunction.h"

class AmplifiedHashFunction
{
    std::vector<HashFunction> hash_functions;
    std::vector<int> random_coefficients;
    int dimension;
    int h_function_count;
    size_t no_of_buckets;
    int w;

public:
    AmplifiedHashFunction(int _dimension, int _h_function_count, size_t _no_of_buckets, int _w);
    std::pair<int, unsigned int> hash_image(Image* img);
};

#endif //AMPLIFIED_H