#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <algorithm>
#include <chrono>

#include "image.h"
#include "utilities.h"
#include "lsh.h"
#include "algorithms.h"
#include "hyperCube.h"
#include "priorityQueue.h"
using namespace std;

int main(int argc, char* argv[])
{
    Arguments args;
    if(argc == 1)
    {
        std::cout << "Error in arguments" << endl;
        return -1;
    }

    if(args.parse_arguments_cube(argc, argv) == false)
    {
        std::cout << "Error in arguments" << endl;
        return -1;
    }

    std::ifstream ifs_input(args.input_file_name);
    std::ifstream ifs_query(args.query_file_name);
    std::ofstream ofs(args.output_file_name);

    int img_no, row_no, col_no;
    vector<Image*> data;
    vector<Image*> query_data;
    read_images(ifs_input, data, img_no, row_no, col_no);
    read_query_images(ifs_query, query_data, row_no, col_no);

    int N = (args.N > 0)? args.N : 4; //N
    int k = (args.k > 0)? args.k : 14; //dimension for projection
    int M = (args.M > 0)? args.M : 10;
    int probes = (args.probes > 0)? args.probes : 2;
    int R = (args.R > 0)? args.R : 10000;
    int dimension = row_no * col_no;
    int w = 4;

    PriorityQueueAscending queue_exact(N);
    PriorityQueueAscending queue_approx(N);
    PriorityQueueAscending queue_range(N);

    auto start_build = std::chrono::high_resolution_clock::now();
    HyperCube hypercube(data, k, M, probes, R, dimension, w);
    auto end_build = std::chrono::high_resolution_clock::now();
    auto tBuild = std::chrono::duration_cast<std::chrono::microseconds>(end_build - start_build);
    std::cout << "Build time: " << tBuild.count() << endl;

    for (int i = 0; i < query_data.size(); i++)
    {
        Image* img = query_data.at(i);
        ofs << "Query: " << img->id + 1 << endl;

        auto start = std::chrono::high_resolution_clock::now();
        exact_kNN(img, data, queue_exact, N);
        auto end_exact = std::chrono::high_resolution_clock::now();
        approximate_kNN_Hypercube(img, k, hypercube, queue_approx, probes, M);
        auto end_approximate = std::chrono::high_resolution_clock::now();

        int size = queue_approx.size();
        for (int j = 0; j < size; j++)
        {
            ofs << "Nearest neighbor-" << j + 1 << ":" << queue_approx.top().img->id << endl;
            ofs << "distanceLSH: " << queue_approx.top().distance << endl;
            ofs << "distanceTrue: " << queue_exact.top().distance << endl;

            queue_approx.pop();
            queue_exact.pop();
        }

        auto tLSH = std::chrono::duration_cast<std::chrono::microseconds>(end_approximate - end_exact);
        auto tTrue = std::chrono::duration_cast<std::chrono::microseconds>(end_exact - start);
        ofs << "tLSH: " << tLSH.count() << endl;
        ofs << "tTrue: " << tTrue.count() << endl;

        approximate_range_search_hypercube(img, k, hypercube, R, queue_range, M, probes);

        ofs << "R near neighbors : " << endl;
        size = queue_range.size();
        for (int j = 0; j < size; j++)
        {
            ofs << queue_range.top().img->id << endl;
            queue_range.pop();
        }
    }
}
