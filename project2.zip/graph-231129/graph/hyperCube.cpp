#include "hyperCube.h"

HyperCube::HyperCube(vector<Image*>& data, int _k, int _M, int _probes, int _R, int _dimension, int _w)
{
    k = _k;
    M = _M;
    probes = _probes;
    R = _R;
    dimension = _dimension;
    w = _w;

    for (int i = 0; i < k; i++)
    {
        //create projectors
        projectors.push_back(new F_Function(dimension, w));
    }

    for (int i = 0; i < data.size(); i++)
    {
        string vertex_index;
        //allocate images to vertices
        for (int j = 0; j < k; j++)
        {
            vertex_index += projectors[j]->calc_zero_or_one(data[i]);
        }

        if (vertices.find(vertex_index) == vertices.end())
            vertices.insert(pair<string, Bucket*>(vertex_index, new Bucket()));

        vertices[vertex_index]->bucket_images.push_back(data[i]);
    }

    cout << "Finished allocation to vertices" << endl;
}
