#ifndef UTILITIES_H
#define UTILITIES_H
#include <iostream>
#include <fstream>
#include <vector>
#include "image.h"

void read_images(std::ifstream& ifs, std::vector<Image*>& data, int& img_no, int& row_no, int& col_no);

void read_query_images(std::ifstream& ifs, std::vector<Image*>& data, int row_no, int col_no);

class Arguments
{
public:
    char* input_file_name = nullptr;
    char* query_file_name = nullptr;
    char* output_file_name = nullptr;
    char* conf_file_name = nullptr; //cluster
    int k;
    int L;
    int N;
    int R;
    int M; //cube
    int probes; //cube
    char* complete; //cluster
    char* method; //cluster
    int E;
    int l;
    int m;

    //cluster.conf
    int number_of_clusters;
    int number_of_vector_hash_tables;
    int number_of_vector_hash_functions;
    int max_number_M_hypercube;
    int number_of_hypercube_dimensions;
    int number_of_probes;

    Arguments();
    bool parse_arguments_lsh(int argc, char* argv[]);
    bool parse_arguments_cube(int argc, char* argv[]);
    bool parse_arguments_cluster(int argc, char* argv[]);
    bool parse_arguments_graph(int argc, char* argv[]);
    bool parse_conf_file(char* conf_file_name);
    void print_arguments();
};

#endif //UTILITIES_H