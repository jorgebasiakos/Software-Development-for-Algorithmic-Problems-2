#ifndef CLUSTER_H
#define CLUSTER_H
#include <vector>
#include <algorithm>
#include "image.h"

class Cluster
{
public:
    Image* centroid;
    std::vector<Image*> images;
    int dimension;

    Cluster(Image* _centroid, int _dimension);
    void add_image_to_cluster(Image* img);
    void update_centroid();
    void print_info(ofstream& ofs);
    void print_complete_info(ofstream& ofs);
};

#endif //CLUSTER_H