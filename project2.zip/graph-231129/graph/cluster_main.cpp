#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <algorithm>
#include <chrono>

#include "image.h"
#include "utilities.h"
#include "lsh.h"
#include "algorithms.h"
#include "hyperCube.h"
#include "clustering.h"
#include "priorityQueue.h"
using namespace std;

int main(int argc, char* argv[])
{
    Arguments args;
    if(argc == 1)
    {
        std::cout << "Error in arguments" << endl;
        return -1;
    }

    if(args.parse_arguments_cluster(argc, argv) == false)
    {
        std::cout << "Error in arguments" << endl;
        return -1;
    }

    std::ifstream ifs_input(args.input_file_name);
    std::ofstream ofs(args.output_file_name);

    bool res = args.parse_conf_file(args.conf_file_name);

    int img_no, row_no, col_no;
    vector<Image*> data;
    read_images(ifs_input, data, img_no, row_no, col_no);

    int number_of_clusters = (args.number_of_clusters > 0) ? args.number_of_clusters : 10;
    int number_of_vector_hash_tables = (args.number_of_vector_hash_tables > 0)? args.number_of_vector_hash_tables : 3;
    int number_of_vector_hash_functions = (args.number_of_vector_hash_functions > 0)? args.number_of_vector_hash_functions : 4;
    int max_number_M_hypercube = (args.max_number_M_hypercube > 0)? args.max_number_M_hypercube : 10;
    int number_of_hypercube_dimensions = (args.number_of_hypercube_dimensions > 0) ? args.number_of_hypercube_dimensions : 3;
    int number_of_probes = (args.number_of_probes > 0)? args.number_of_probes : 2;
    int w = 4;
    int R = 10000;

    std::vector<Cluster*> clusters;
    auto start = std::chrono::high_resolution_clock::now();

    if(strcmp(args.method, "Classic") == 0)
    {
        clustering_lloyds(clusters, data, number_of_clusters, row_no * col_no);
        ofs << "Algorithm: Lloyds" << endl;
    }
    else if(strcmp(args.method, "LSH") == 0)
    {
        LSH lsh(data, number_of_vector_hash_tables, number_of_vector_hash_functions, row_no * col_no, w, 8);
        clustering_LSH(clusters, data, lsh, number_of_clusters);
        ofs << "Algorithm: Range Search Hypercube" << endl;
    }
    else if(strcmp(args.method, "Hypercube") == 0)
    {
        HyperCube hypercube(data, number_of_hypercube_dimensions, max_number_M_hypercube, number_of_probes, R, row_no * col_no, w);
        clustering_hypercube(clusters, data, hypercube, number_of_clusters);
        ofs << "Algorithm: Range Search LSH" << endl;
    }

    print_cluster_info(ofs, clusters);

    auto end = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end - start);
    ofs << "\nclustering time: " << duration.count();

    std::vector<double> silhouettes = silhouette(clusters);
    ofs << "\nSilhouette: [";
    for (int i = 0; i < silhouettes.size(); i++)
        ofs << silhouettes.at(i) << ", ";
    ofs << "]" << endl;

    if(strcmp(args.complete, "true") == 0)
    {
        print_complete_cluster_info(ofs, clusters);
    }
}

