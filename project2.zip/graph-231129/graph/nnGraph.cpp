#include "nnGraph.h"
#include "algorithms.h"

NNGraph::NNGraph(vector<Image*>& _data, LSH* _lsh, int _k, int _E, int _R, int _N)
{
    data = _data;
    lsh = _lsh;
    k = _k;
    E = _E;
    R = _R;
    N = _N;

    cout << "Starting graph creation.." << endl;

    for(int i = 0; i < data.size(); i++)
    {
        PriorityQueueAscending queue(k);
        list<int> temp_list;
        approximate_kNN_LSH(data.at(i), *lsh, queue, k);

        int size = queue.size();
        for (int j = 0; j < size; j++)
        {
            if(queue.top().img->id != i)
            {
                temp_list.push_back(queue.top().img->id);
            }
            queue.pop();
        }

        lists.insert(pair<int, list<int>>(data.at(i)->id, temp_list));

        if(i % 1000 == 0)
            std:cout << i << " " ;
            std::cout.flush();
    }
}