#ifndef MRNGRAPH_H
#define MRNGRAPH_H
#include <vector>
#include <unordered_map>
#include <list>
#include "image.h"
#include "lsh.h"

class MrnGraph
{
    public:
    std::vector<Image*>* data;
    int l;
    int N;
    unordered_map<int, list<int>> neighbors_per_point;
    MrnGraph(std::vector<Image*>* _data, LSH *lsh, int _l, int _N);
};

#endif //MRNGRAPH_H 