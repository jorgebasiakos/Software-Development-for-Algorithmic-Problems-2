#ifndef HASH_TABLE_H
#define HASH_TABLE_H
#include <unordered_map>
#include <vector>
#include <utility>
#include "bucket.h"
#include "image.h"
#include "amplifiedHashFunction.h"

class HashTable
{
public:
    size_t size;
    int dimension;
    AmplifiedHashFunction g_hash;
    std::unordered_map<int, Bucket*> buckets;
    int hash_table_divisor;

    HashTable(std::vector<Image*>& images, int _dimension, int _h_function_count, int _w, int _hash_table_divisor);
};

#endif //HASH_TABLE_H