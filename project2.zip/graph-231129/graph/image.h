#ifndef IMAGE_H
#define IMAGE_H
#include <iostream>
#include <fstream>
#include <cstring>

using namespace std;

class Image
{
public:
    unsigned char* data;
    int id;

    Image(unsigned char* d, int _id);
    void print();
    void print_to_file(ofstream& ofs);
};

#endif //IMAGE_H