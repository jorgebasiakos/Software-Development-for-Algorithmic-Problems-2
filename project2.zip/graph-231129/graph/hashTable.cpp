#include "hashTable.h"

HashTable::HashTable(std::vector<Image*>& images, int _dimension, int _h_function_count, int _w, int _hash_table_divisor)
    :g_hash(_dimension, _h_function_count, images.size() / _hash_table_divisor, _w)
{
    dimension = _dimension;
    hash_table_divisor = _hash_table_divisor;
    size = images.size() / hash_table_divisor; //number of buckets in the hash table

    //allocate images into buckets
    for (int i = 0; i < images.size(); i++)
    {
        //get hash of each image
        std::pair<int, unsigned int> p = g_hash.hash_image(images.at(i));

        //if bucket has not been created yet --> create it
        if (buckets.find(p.first) == buckets.end())
            buckets.insert(std::pair<int, Bucket*>(p.first, new Bucket()));

        buckets.at(p.first)->bucket_images.push_back(images.at(i));
        buckets.at(p.first)->ids.push_back(p.second);
    }

    cout << "hash table size=" << buckets.size() << " buckets" << endl;
}
