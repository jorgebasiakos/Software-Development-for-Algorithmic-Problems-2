#include "cluster.h"

Cluster::Cluster(Image* _centroid, int _dimension)
{
    centroid = _centroid;
    dimension = _dimension;
}

void Cluster::add_image_to_cluster(Image* img)
{
    images.push_back(img);
}

void Cluster::update_centroid()
{
    unsigned char* median = new unsigned char[dimension];
    //calculate median of all images for this cluster
    for (int i = 0; i < dimension; ++i)
    {
        vector<unsigned char> pixels_at_dimension;
        for (int j = 0; j < images.size(); j++)
        {
            pixels_at_dimension.push_back(images.at(j)->data[i]);
        }
        std::sort(pixels_at_dimension.begin(), pixels_at_dimension.end());
        median[i] = pixels_at_dimension.at(pixels_at_dimension.size() / 2);
    }
    delete centroid;
    centroid = new Image(median, 0);
}

void Cluster::print_info(ofstream& ofs)
{
    ofs << "{size: " << images.size() << " ,\ncentroid: " << endl;
    centroid->print_to_file(ofs);
    ofs << " } " << endl;
}

void Cluster::print_complete_info(ofstream& ofs)
{
    ofs << "{" ;
    ofs << dec << centroid->id << ", ";
    for(int i = 0; i < images.size() - 1; i++)
        ofs << dec << images.at(i)->id << ", "; 
    ofs << images.at(images.size()-1)->id << " } " << endl;
}
