#ifndef CLUSTERING_H
#define CLUSTERING_H
#include <random>
#include <vector>
#include <limits>

#include "image.h"
#include "cluster.h"
#include "lsh.h"
#include "hyperCube.h"
#include "algorithms.h"

std::vector<double> calculate_probabilities(std::vector<Image*>& data, vector<Image*>& centroids);

int binary_search(std::vector<double>& probs, double search_value, int start, int end);

vector<Image*> select_initial_centroids(std::vector<Image*>& data, int total_clusters);

void initial_assignment_lloyds(std::vector<Image*>& data, std::vector<Cluster*>& clusters);

int reassignment(std::vector<Cluster*>& clusters);

void update_centroids(std::vector<Cluster*>& clusters);

int assignment_LSH_reverse_search(std::vector<Cluster*>& clusters, LSH& lsh);

int assignment_hypercube_reverse_search(std::vector<Cluster*>& clusters, HyperCube& hypercube);

void print_cluster_info(ofstream& ofs, std::vector<Cluster*>& clusters);

void print_complete_cluster_info(ofstream& ofs, std::vector<Cluster*>& clusters);

void clustering_lloyds(std::vector<Cluster*>& clusters, std::vector<Image*>& data, int total_clusters, int dimension);

void clustering_LSH(std::vector<Cluster*>& clusters, std::vector<Image*>& data, LSH& lsh, int total_clusters);

void clustering_hypercube(std::vector<Cluster*>& clusters, std::vector<Image*>& data, HyperCube& hypercube, int total_clusters);

std::vector<double> silhouette(std::vector<Cluster*>& clusters);

#endif //CLUSTERING_H