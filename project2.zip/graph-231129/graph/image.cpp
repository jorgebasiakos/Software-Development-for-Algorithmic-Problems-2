#include "image.h"

Image::Image(unsigned char* d, int _id)
{
    id = _id;
    data = new unsigned char[784];
    memcpy(this->data, d, 784);
}

void Image::print()
{
    for (int j = 0; j < 784; j++)
    {
        cout << hex << data[j];
        if (j % 28 == 0)
            cout << endl;
    }
}

void Image::print_to_file(ofstream& ofs)
{
    for (int j = 0; j < 784; j++)
    {
        ofs << hex << data[j];
        if (j % 28 == 0)
            ofs << endl;
    }
}
