#ifndef QUEUE_H
#define QUEUE_H
#include <queue>
#include "image.h"

class ImageDistancePair
{
public:
    Image* img;
    double distance;

    ImageDistancePair(Image* _img, double _distance);
};

class CompareAscending
{
public:
    bool operator() (ImageDistancePair& idp1, ImageDistancePair& idp2);
};


class PriorityQueueAscending
{
public:
    std::priority_queue<ImageDistancePair, std::vector<ImageDistancePair>, CompareAscending> queue;
    int N; 

    PriorityQueueAscending(int _N);
    PriorityQueueAscending();
    int size();
    void push_limited(Image* img, double distance);
    void push(Image* data_img, double distance);
    ImageDistancePair top();
    void pop();
};

#endif //QUEUE_H