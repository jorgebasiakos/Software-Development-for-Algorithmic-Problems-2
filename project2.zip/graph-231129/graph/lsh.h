#ifndef LSH_H
#define LSH_H
#include <vector>
#include "hashTable.h"

class LSH
{
public:
    std::vector<HashTable> hash_tables;

    int table_count;  //L
    int h_function_count; //k
    int dimension;
    int w;
    int hash_table_divisor;

    LSH(vector<Image*>& data, int _table_count, int _h_function_count, int _dimension, int _w, int _hash_table_divisor);
};

#endif //LSH_H