#include "bucket.h"

Bucket::Bucket()
{

}