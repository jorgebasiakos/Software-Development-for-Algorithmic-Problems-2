#include "hashFunction.h"

HashFunction::HashFunction(int _dimension, int _w)
{
    dimension = _dimension;
    w = _w;

    std::random_device rd;
    std::mt19937 gen(rd());
    std::normal_distribution<double> normal_dist(0.0, 1.0);
    for (int i = 0; i < dimension; i++)
    {
        vector_v.push_back(normal_dist(gen));
    }

    std::uniform_int_distribution<int> uniform_dist(0, w);
    t = uniform_dist(gen);
}

unsigned int HashFunction::hash_image(Image* img)
{
    unsigned int sum = 0;
    //calculate hash over image data
    for (int i = 0; i < dimension; i++)
    {
        sum += (int)img->data[i] * (int)vector_v[i];
    }
    return (sum + t) / w;
}
