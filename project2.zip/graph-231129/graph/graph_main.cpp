#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <algorithm>
#include <chrono>

#include "image.h"
#include "utilities.h"
#include "lsh.h"
#include "algorithms.h"
#include "hyperCube.h"
#include "priorityQueue.h"
#include "nnGraph.h"
#include "mrnGraph.h"

using namespace std;

int main(int argc, char** argv)
{
    Arguments args;
    std::ifstream ifs_input;
    std::ifstream ifs_query;
    std::ofstream ofs;

    if(args.parse_arguments_graph(argc, argv) == false)
    {
        std::cout << "Error in arguments" << endl;
        return -1;
    }

    //open files
    string str;
    if(args.input_file_name == nullptr)
    {
        std::cout << "Please give the dataset path: ";
        getline(std::cin, str);
        args.input_file_name = new char[str.length() +1];
        strcpy(args.input_file_name, str.c_str());
    }

    ifs_input.open(args.input_file_name, ios::binary);
    if(!ifs_input)
    {
        cout << "File could not be opened" << endl;
        return 0;
    }

    if(args.query_file_name == nullptr)
    {
        std::cout << "Please give the query file path: ";
        getline(std::cin, str);
        args.query_file_name = new char[str.length() +1];
        strcpy(args.query_file_name, str.c_str());
    }

    ifs_query.open(args.query_file_name, ios::binary);
    if(!ifs_query)
    {
        cout << "File could not be opened" << endl;
        return 0;
    }

    if(args.output_file_name == nullptr)
    {
        std::cout << "Please give the output file path: ";
        getline(std::cin, str);
        args.output_file_name = new char[str.length() +1];
        strcpy(args.output_file_name, str.c_str());
    }

    ofs.open(args.output_file_name);
    if(!ofs)
    {
        cout << "File could not be opened" << endl;
        return 0;
    }

    int img_no, row_no, col_no;
    vector<Image*> data;
    vector<Image*> query_data;
    read_images(ifs_input, data, img_no, row_no, col_no);
    read_query_images(ifs_query, query_data, row_no, col_no);

    //default values
    int k = (args.k > 0)? args.k : 50;
    int E = (args.E > 0)? args.E : 30;
    int R = (args.R > 0)? args.R : 1;
    int N = (args.N > 0)? args.N : 4;
    int l = (args.l > 0)? args.l : 20;
    int m = (args.m > 0)? args.m : 2;

    int table_count = 5;
    int h_function_count = 4;
    int hash_table_divisor = 16;
    int dimension = row_no * col_no;
    int w = 4;

    PriorityQueueAscending queue_exact(N);
    PriorityQueueAscending queue_approx(N);

    //init LSH
    cout << "Creating LSH.. " << endl;
    LSH lsh(data, table_count, h_function_count, dimension, w, hash_table_divisor);

    if(m == 1)
    {
        //build graph
        auto start_build = std::chrono::high_resolution_clock::now();
        NNGraph graph(data, &lsh, k, E, R, N);
        auto end_build = std::chrono::high_resolution_clock::now();
        auto tBuild = std::chrono::duration_cast<std::chrono::microseconds>(end_build - start_build);
        std::cout << "Build time: " << tBuild.count() << endl;

        ofs << "GNNS Results" << endl;

        //for each query image
        for(int i = 0; i < query_data.size(); i++)
        {
            Image* img = query_data.at(i);
            ofs << "Query: " << img->id + 1 << endl;

            auto start = std::chrono::high_resolution_clock::now();
            cout << endl << "Starting exact calculation.." << endl;
            exact_kNN(img, data, queue_exact, N);
            auto end_exact = std::chrono::high_resolution_clock::now();
            cout << "Starting GNNS calculation.." << endl;
            GNNS_algorithm(img, graph, queue_approx, N);
            auto end_approximate = std::chrono::high_resolution_clock::now();

            int size = queue_approx.size();
            for (int j = 0; j < size; j++)
            {
                ofs << "Nearest neighbor-" << j + 1 << ":" << queue_approx.top().img->id << endl;
                ofs << "distanceApproximate: " << queue_approx.top().distance << endl;
                ofs << "distanceTrue: " << queue_exact.top().distance << endl;

                queue_approx.pop();
                queue_exact.pop();
            }

            auto tApprox = std::chrono::duration_cast<std::chrono::microseconds>(end_approximate - end_exact);
            auto tTrue = std::chrono::duration_cast<std::chrono::microseconds>(end_exact - start);
            ofs << "tAverageApproximate: " << tApprox.count() << endl;
            ofs << "tAverageTrue: " << tTrue.count() << endl;
        }

    }
    else
    {
        //build graph
        cout << "Building graph" << endl;
        auto start_build = std::chrono::high_resolution_clock::now();
        MrnGraph graph(&data, &lsh, l, N);
        auto end_build = std::chrono::high_resolution_clock::now();
        auto tBuild = std::chrono::duration_cast<std::chrono::microseconds>(end_build - start_build);
        std::cout << "Build time: " << tBuild.count() << endl;

        ofs << "MRNG Results" << endl;

        //for each query image
        for(int i = 0; i < query_data.size(); i++)
        {
            Image* img = query_data.at(i);
            ofs << "Query: " << img->id + 1 << endl;

            auto start = std::chrono::high_resolution_clock::now();
            cout << endl << "Starting exact calculation.." << endl;
            exact_kNN(img, data, queue_exact, N);
            auto end_exact = std::chrono::high_resolution_clock::now();
            cout << "Starting Search-on-Graph calculation.." << endl;
            Search_on_Graph_algorithm(img, data, graph, queue_approx, N, l);
            auto end_approximate = std::chrono::high_resolution_clock::now();

            int size = queue_approx.size();
            for (int j = 0; j < size; j++)
            {
                ofs << "Nearest neighbor-" << j + 1 << ":" << queue_approx.top().img->id << endl;
                ofs << "distanceApproximate: " << queue_approx.top().distance << endl;
                ofs << "distanceTrue: " << queue_exact.top().distance << endl;

                queue_approx.pop();
                queue_exact.pop();
            }

            auto tApprox = std::chrono::duration_cast<std::chrono::microseconds>(end_approximate - end_exact);
            auto tTrue = std::chrono::duration_cast<std::chrono::microseconds>(end_exact - start);
            ofs << "tAverageApproximate: " << tApprox.count() << endl;
            ofs << "tAverageTrue: " << tTrue.count() << endl;
        }
    }

    std::cout << "finished" << endl;
}
