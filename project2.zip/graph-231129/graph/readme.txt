Ομάδα(Μέλη):
Γεώργος Μπασιάκος - ΑΜ: 1115201700097
Ευάγγελος Λαζαράκης - ΑΜ: 1115201600085

Οι συναρτήσεις main() :
-lsh_main.cpp
-cube_main.cpp
-cluster_main.cpp
-graph_main.cpp

Οι αλγόριθμοι:
-algorithms.cpp              --> οι αλγόριθμοι LSH και Hypercube
-algorithms.h
-clustering.cpp              --> οι αλγόριθμοι clustering
-clustering.h

Οι δομές:
-lsh.cpp
-lsh.h
-hyperCube.cpp
-hyperCube.h
-cluster.cpp                 
-cluster.h
-mrnGraph.cpp
-mrnGraph.h
-nnGraph.cpp
-nnGraph.h

Οι κλάσεις κοινής χρήσης:
-amplifiedHashFunction.cpp   --> G function
-amplifiedHashFunction.h
-bucket.cpp                  --> bucket
-bucket.h
-f_Function.cpp              --> F function
-f_Function.h
-hashFunction.cpp            --> hash function
-hashFunction.h
-hashTable.cpp               --> hash table
-hashTable.h
-image.cpp                  --> image class
-image.h
-priorityQueue.cpp          --> custom priority queue class
-priorityQueue.h
-utilities.cpp              --> various utilities
-utilities.h

Τα αρχεία εισόδου:
-input.dat
-query.dat
-cluster.conf

Επίσης:
-Makefile
-readme.txt

Οδηγίες μεταγλώττισης:
%make clean
%make

Οδηγίες χρήσης:
./lsh -d <input file> -q <query file> -k <int> -L <int> -o <output file> -N <number of nearest> -R <radius>
./cube -d <input file> -q <query file> -k <int> -M <int> -probes <int> -o <output file> -N <number of nearest> -R <radius>
./cluster -i <input file> -c <configuration file> -o <output file> -complete <optional> -m <method : Classic OR LSH or Hypercube>
./graph_search –d <input file> –q <query file> –k <int> -E <int> -R <int> -N <int> -l <int, only for Search-on-Graph> -m <1 for GNNS, 2 for MRNG> -o <output file>

