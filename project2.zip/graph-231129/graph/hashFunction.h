#ifndef HASH_FUNCTION_H
#define HASH_FUNCTION_H
#include <random>
#include <vector>
#include "image.h"

class HashFunction
{
public:
    int dimension;
    double t;
    int w;
    std::vector<double> vector_v;

    HashFunction(int _dimension, int _w);
    unsigned int hash_image(Image* img);
};

#endif //HASH_FUNCTION_H