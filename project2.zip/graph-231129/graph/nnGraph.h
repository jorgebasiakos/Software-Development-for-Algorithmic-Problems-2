#ifndef GRAPH_H
#define GRAPH_H
#include "lsh.h"
#include "priorityQueue.h"
#include <unordered_map>
#include <list>

class NNGraph
{
    public:
    std::unordered_map<int, std::list<int>> lists;
    vector<Image*> data;
    LSH* lsh;
    int k;
    int l;
    int E;
    int R;
    int N;

    NNGraph(vector<Image*>& _data, LSH* _lsh, int _k, int _E, int _R, int _N);

};

#endif //GRAPH_H