#include "f_Function.h"

F_Function::F_Function(int _dimension, int _w) :hash_function(_dimension, _w)
{
    dimension = _dimension;
    w = _w;
}

char F_Function::calc_zero_or_one(Image* img)
{
    int hash = hash_function.hash_image(img);

    if (f_mappings.find(hash) == f_mappings.end())
    {
        //key not found-->add it
        std::random_device rd;
        std::mt19937 gen(rd());
        std::uniform_int_distribution<int> uniform_dist(0, 1);

        char bit = uniform_dist(gen) == 0 ? '0' : '1';
        f_mappings.insert(pair<int, char>(hash, bit));
        return bit;
    }

    return f_mappings.at(hash);
}
