#include "clustering.h"

std::vector<double> calculate_probabilities(std::vector<Image*>& data, vector<Image*>& centroids)
{
    std::vector<double> probs;
    probs.push_back(0.0);

    for (int i = 0; i < data.size(); i++)
    {
        double min_dist = std::numeric_limits<double>::max();
        for (int j = 0; j < centroids.size(); j++)
        {
            double temp_dist = dist(data.at(i), centroids.at(j));
            if (temp_dist < min_dist)
                min_dist = temp_dist;
        }
        probs.push_back(min_dist);
    }

    double max_dist_in_vector = *max_element(probs.begin(), probs.end());
    for (int i = 1; i < probs.size(); i++)
    {
        //normalize probabilties in [0, 1]
        probs.at(i) /= max_dist_in_vector;

        //calculate p(i)
        probs.at(i) = pow(probs.at(i), 2) + probs.at(i - 1);
    }

    return probs;
}

int binary_search(std::vector<double>& probs, double search_value, int start, int end)
{
    //search inside the probabilities vector
    while (start <= end)
    {
        int middle = start + (end - start) / 2;

        if (probs.at(middle) == search_value)
            return middle;

        if (probs.at(middle) < search_value)
            start = middle + 1;
        else
            end = middle - 1;
    }
    if (probs.at(start) >= search_value)
        return start;
    else
        return start + 1;
}

vector<Image*> select_initial_centroids(std::vector<Image*>& data, int total_clusters)
{
    std::vector<Image*> centroids;
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<int> uniform_dist(0, (int)data.size() - 1);

    //random centroid selection
    int centroid_index = uniform_dist(gen);
    Image* img = data.at(centroid_index);
    centroids.push_back(img);
    data.erase(data.begin() + centroid_index);

    cout << "Starting initial centroid selection... " << endl;

    for (int i = 1; i < total_clusters; i++)
    {
        vector<double> probabilities = calculate_probabilities(data, centroids);
        uniform_real_distribution<double> uniform_real_dist(0, probabilities.at(probabilities.size() - 1));

        double search_value = uniform_real_dist(gen);
        int index = binary_search(probabilities, search_value, 0, (int)probabilities.size() - 1);

        centroids.push_back(data.at(index));
        data.erase(data.begin() + index);
    }
    return centroids;
}

void initial_assignment_lloyds(std::vector<Image*>& data, std::vector<Cluster*>& clusters)
{
    cout << "Assigning each image to a cluster.." << endl;

    for (int i = 0; i < data.size(); i++)
    {
        double min_distance = numeric_limits<int>::max();
        int cluster_id = 0;
        //allocate each image to the closest cluster
        for (int j = 0; j < clusters.size(); j++)
        {
            double temp_distance = dist(data.at(i), clusters.at(j)->centroid);
            if (temp_distance < min_distance)
            {
                min_distance = temp_distance;
                cluster_id = j;
            }
        }
        clusters.at(cluster_id)->add_image_to_cluster(data.at(i));
    }
}

int reassignment(std::vector<Cluster*>& clusters)
{
    int total_reassignments = 0;
    cout << "Reassigning each image to a cluster.." << endl;

    for (int i = 0; i < clusters.size(); i++)
    {
        for (int j = 0; j < clusters.at(i)->images.size(); j++)
        {
            double min_distance = numeric_limits<int>::max();
            int new_cluster_id = 0;
            for (int k = 0; k < clusters.size(); k++)
            {
                double temp_distance = dist(clusters.at(i)->images.at(j), clusters.at(k)->centroid);
                if (temp_distance < min_distance)
                {
                    min_distance = temp_distance;
                    new_cluster_id = k;
                }
            }

            //if reallocation is needed
            if (new_cluster_id != i)
            {
                clusters.at(new_cluster_id)->add_image_to_cluster(clusters.at(i)->images.at(j));
                clusters.at(i)->images.erase(clusters.at(i)->images.begin() + j);
                total_reassignments++;
            }
        }
    }
    return total_reassignments;
}

void update_centroids(std::vector<Cluster*>& clusters)
{
    cout << "Updating centroids.." << endl;
    for (int i = 0; i < clusters.size(); i++)
    {
        clusters.at(i)->update_centroid();
    }
}

int assignment_LSH_reverse_search(std::vector<Cluster*>& clusters, LSH& lsh)
{
    int threshold = 10; 
    int cluster_threshold = 10; 
    int total_points_assigned = 0;
    int previous_total_points_assigned = 0;

    //find the minimum distance between centroids
    double radius = numeric_limits<double>::max();
    for (int i = 0; i < clusters.size(); i++)
    {
        for (int j = i + 1; j < clusters.size(); j++)
        {
            double temp_distance = dist(clusters.at(i)->centroid, clusters.at(j)->centroid);
            if (temp_distance < radius)
            {
                radius = temp_distance;
            }
        }
    }

    //start with half the radius
    radius /= 2;

    while (true)
    {
        for (int i = 0; i < clusters.size(); i++)
        {
            int no_of_checks = 0;

            //assign each centroid to a specific hash table
            for (int j = 0; j < lsh.hash_tables.size(); j++)
            {
                pair<int, unsigned int> hash_result = lsh.hash_tables.at(j).g_hash.hash_image(clusters.at(i)->centroid);
                Bucket* bucket = lsh.hash_tables.at(j).buckets.at(hash_result.first);

                //get all images from this bucket, that are within the radius
                for (int j = 0; j < bucket->bucket_images.size(); j++)
                {
                    //distance between centroid and image in bucket
                    double distance = dist(clusters.at(i)->centroid, bucket->bucket_images.at(j));
                    if (distance < radius && distance > 0)
                    {
                        clusters.at(i)->add_image_to_cluster(bucket->bucket_images.at(j));
                        total_points_assigned++;
                    }
                    if (++no_of_checks >= 2 * threshold * lsh.hash_tables.size())
                        break;
                }
                if (no_of_checks >= 2 * threshold * lsh.hash_tables.size())
                    break;
            }
        }
        if (previous_total_points_assigned == total_points_assigned && total_points_assigned > 0)
            break;
        else
        {
            previous_total_points_assigned = total_points_assigned;
            total_points_assigned = 0;
        }

        //double the radius
        radius *= 2;
    }

    return total_points_assigned;
}

int assignment_hypercube_reverse_search(std::vector<Cluster*>& clusters, HyperCube& hypercube)
{
    int threshold = 10;  
    int cluster_threshold = 10;
    int total_points_assigned = 0;
    int previous_total_points_assigned = 0;

    //find the minimum distance between centroids
    double radius = numeric_limits<double>::max();
    for (int i = 0; i < clusters.size(); i++)
    {
        for (int j = i + 1; j < clusters.size(); j++)
        {
            double temp_distance = dist(clusters.at(i)->centroid, clusters.at(j)->centroid);
            if (temp_distance < radius)
            {
                radius = temp_distance;
            }
        }
    }

    //start with half the radius
    radius /= 2;

    while (true)
    {
        for (int i = 0; i < clusters.size(); i++)
        {
            int no_of_checks = 0;
            string vertex_index;
            std::vector<string> sorted_vertex_vec;
            int maximum_points_checked = 0;

            //find image vertex
            for (int j = 0; j < hypercube.k; j++)
                vertex_index += hypercube.projectors.at(j)->calc_zero_or_one(clusters.at(i)->centroid);

            sort_vertices_by_Hamming_distance(sorted_vertex_vec, vertex_index, hypercube.probes);

            for (int jj = 0; jj < sorted_vertex_vec.size(); jj++)
            {
                for (int k = 0; k < hypercube.vertices.at(sorted_vertex_vec[jj])->bucket_images.size(); k++)
                {
                    double temp_distance = dist(hypercube.vertices.at(sorted_vertex_vec[jj])->bucket_images.at(k), clusters.at(i)->centroid);
                    if (temp_distance <= radius && temp_distance > 0)
                    {
                        clusters.at(i)->add_image_to_cluster(hypercube.vertices.at(sorted_vertex_vec[jj])->bucket_images.at(k));
                        total_points_assigned++;
                    }

                    if (++maximum_points_checked > hypercube.M)
                        break;
                }
                if (maximum_points_checked > hypercube.M)
                    break;
            }
        }
        if (previous_total_points_assigned == total_points_assigned && total_points_assigned > 0)
            break;
        else
        {
            previous_total_points_assigned = total_points_assigned;
            total_points_assigned = 0;
        }

        //double the radius
        radius *= 2;
    }

    return total_points_assigned;
}

void print_cluster_info(ofstream& ofs, std::vector<Cluster*>& clusters)
{
    for (int i = 0; i < clusters.size(); i++)
    {
        ofs << endl << "CLUSTER-" << i + 1 << " ";
        clusters.at(i)->print_info(ofs);
    }
}

void print_complete_cluster_info(ofstream& ofs, std::vector<Cluster*>& clusters)
{
    for (int i = 0; i < clusters.size(); i++)
    {
        ofs << endl << "CLUSTER-" << i + 1 << " ";
        clusters.at(i)->print_complete_info(ofs);
    }
}

void clustering_lloyds(std::vector<Cluster*>& clusters, std::vector<Image*>& data, int total_clusters, int dimension)
{
    std::vector<Image*> initial_centroids = select_initial_centroids(data, total_clusters);

    //create clusters
    for (int i = 0; i < total_clusters; i++)
    {
        clusters.push_back(new Cluster(initial_centroids.at(i), dimension));
    }

    initial_assignment_lloyds(data, clusters);

    int iterations = 0;
    while (iterations < 10)
    {
        int total_reassignments = 0;
        update_centroids(clusters);
        total_reassignments += reassignment(clusters);
        cout << "total reassignments: " << total_reassignments << endl;
        if (total_reassignments <= 10)
            break;

        iterations++;
        cout << "Finished iteration no." << iterations << endl;
    }
}

void clustering_LSH(std::vector<Cluster*>& clusters, std::vector<Image*>& data, LSH& lsh, int total_clusters)
{
    std::vector<Image*> initial_centroids = select_initial_centroids(data, total_clusters);

    for (int i = 0; i < total_clusters; i++)
    {
        clusters.push_back(new Cluster(initial_centroids.at(i), lsh.dimension));
    }

    int total_assignments = 0;
    total_assignments += assignment_LSH_reverse_search(clusters, lsh);
    cout << "total assignments: " << total_assignments << endl;

    int iterations = 0;
    while (iterations < 10)
    {
        update_centroids(clusters);

        int total_reassignments = reassignment(clusters);
        cout << "total reassignments: " << total_reassignments << endl;
        if (total_reassignments <= 10)
            break;

        iterations++;
        cout << "Finished iteration no." << iterations << endl;
    }
}

void clustering_hypercube(std::vector<Cluster*>& clusters, std::vector<Image*>& data, HyperCube& hypercube, int total_clusters)
{
    std::vector<Image*> initial_centroids = select_initial_centroids(data, total_clusters);

    for (int i = 0; i < total_clusters; i++)
    {
        clusters.push_back(new Cluster(initial_centroids.at(i), hypercube.dimension));
    }

    int total_assignments = 0;
    total_assignments += assignment_hypercube_reverse_search(clusters, hypercube);
    cout << "total assignments: " << total_assignments << endl;

    int iterations = 0;
    while (iterations < 10)
    {
        update_centroids(clusters);

        int total_reassignments = reassignment(clusters);
        cout << "total reassignments: " << total_reassignments << endl;
        if (total_reassignments <= 10)
            break;

        iterations++;
        cout << "Finished iteration no." << iterations << endl;
    }
}

std::vector<double> silhouette(std::vector<Cluster*>& clusters)
{
    cout << "Starting silhouette calculation" << endl;
    vector<double> silhouettes;
    double total = 0;

    for (int i = 0; i < clusters.size(); i++)
    {
        cout << ".";

        double sum = 0;
        for (int j = 0; j < clusters.at(i)->images.size(); j++)
        {
            double min_distance = numeric_limits<double>::max();
            int closest_cluster_id = 0;
            for (int k = 0; k < clusters.size(); k++)
            {
                if (k != i)
                {
                    double temp_distance = dist(clusters.at(i)->images.at(j), clusters.at(k)->centroid);
                    if (temp_distance < min_distance)
                    {
                        closest_cluster_id = k;
                    }
                }
            }

            //calculate average distance of image to each image of the closest cluster
            double total_distance = 0;
            for (int jj = 0; jj < clusters.at(closest_cluster_id)->images.size(); jj++)
            {
                total_distance += dist(clusters.at(i)->images.at(j), clusters.at(closest_cluster_id)->images.at(jj));
            }
            double average_distance_closest = total_distance / clusters.at(closest_cluster_id)->images.size();

            //calculate average distance of image to each image of its own cluster
            total_distance = 0;
            for (int jj = 0; jj < clusters.at(i)->images.size(); jj++)
            {
                if (jj != j)
                    total_distance += dist(clusters.at(i)->images.at(j), clusters.at(i)->images.at(jj));
            }
            double average_distance_same = total_distance / clusters.at(closest_cluster_id)->images.size();

            double max_distance = max(average_distance_closest, average_distance_same);

            sum += (average_distance_closest - average_distance_same) / max_distance;
        }
        silhouettes.push_back(sum / clusters.at(i)->images.size());
        total += sum / clusters.at(i)->images.size();
    }
    silhouettes.push_back(total);

    std::cout << endl;

    return silhouettes;
}