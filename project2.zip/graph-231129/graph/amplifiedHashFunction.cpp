#include "amplifiedHashFunction.h"

AmplifiedHashFunction::AmplifiedHashFunction(int _dimension, int _h_function_count, size_t _no_of_buckets, int _w)
{
    dimension = _dimension;
    h_function_count = _h_function_count;
    no_of_buckets = _no_of_buckets;
    w = _w;

    //create h functions
    for (int i = 0; i < h_function_count; i++)
    {
        std::random_device rd;
        std::mt19937 gen(rd());
        std::uniform_int_distribution<int> uniform_dist(INT_MIN, INT_MAX);
        random_coefficients.push_back(uniform_dist(gen));

        hash_functions.push_back(HashFunction(dimension, w));
    }
}

std::pair<int, unsigned int> AmplifiedHashFunction::hash_image(Image* img)
{
    //hash image
    unsigned int hash = 0;
    for (int i = 0; i < hash_functions.size(); i++)
    {
        hash += hash_functions[i].hash_image(img) * random_coefficients[i];
    }
    int id = hash % (int)(pow(2, 32) - 5);

    //the returned pair contains the bucket number and the ID() of the image
    return std::pair<int, unsigned int>(id % no_of_buckets, id);
}
