#ifndef BUCKET_H
#define BUCKET_H
#include <vector>
#include "image.h"

class Bucket
{
public:
    std::vector<Image*> bucket_images;
    std::vector<unsigned int> ids;

    Bucket();
};

#endif //BUCKET_H