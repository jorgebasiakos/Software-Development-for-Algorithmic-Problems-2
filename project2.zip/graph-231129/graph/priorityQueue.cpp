#include "priorityQueue.h"

ImageDistancePair::ImageDistancePair(Image* _img, double _distance)
{
    img = _img;
    distance = _distance;
}

//The comparator used to sort the pairs in the priority queue
bool CompareAscending::operator() (ImageDistancePair& idp1, ImageDistancePair& idp2)
{
    if (idp1.distance >= idp2.distance)
        return true;
    return false;
}

PriorityQueueAscending::PriorityQueueAscending(int _N)
{
    N = _N;
}

PriorityQueueAscending::PriorityQueueAscending()
{
    N = 0;
}

int PriorityQueueAscending::size()
{
    return (int)queue.size();
}

//push into the queue only up to N items
//if ther are more --> remove existing items from the queue
void PriorityQueueAscending::push_limited(Image* img, double distance)
{
    if (queue.size() < N)
        queue.push(ImageDistancePair(img, distance));
    else
    {
        ImageDistancePair idp = queue.top();
        if (distance < idp.distance)
        {
            std::priority_queue<ImageDistancePair, std::vector<ImageDistancePair>, CompareAscending> temp_queue;
            int size = (int)queue.size();
            for (int i = 0; i < size - 1; i++)
            {
                temp_queue.push(queue.top());
                queue.pop();
            }
            queue.pop();

            size = (int)temp_queue.size();
            for (int i = 0; i < size; i++)
            {
                queue.push(temp_queue.top());
                temp_queue.pop();
            }

            queue.push(ImageDistancePair(img, distance));
        }
    }
}

// push into queue without regard for N
void PriorityQueueAscending::push(Image* data_img, double distance)
{
    queue.push(ImageDistancePair(data_img, distance));
}

ImageDistancePair PriorityQueueAscending::top()
{
    return queue.top();
}

void PriorityQueueAscending::pop()
{
    queue.pop();
}
