#ifndef HYPERCUBE_H
#define HYPERCUBE_H
#include <vector>
#include <unordered_map>
#include "f_Function.h"
#include "bucket.h"

class HyperCube
{
public:
    std::vector<F_Function*> projectors;
    std::unordered_map<string, Bucket*> vertices;

    int k; //dimension for projection
    int M;
    int probes;
    int R;
    int dimension;
    int w;

    HyperCube(vector<Image*>& data, int _k, int _M, int _probes, int _R, int _dimension, int _w);
};

#endif //HYPERCUBE_H