#include "algorithms.h"
#include "mrnGraph.h"

//euclidian distance
double dist(Image* a, Image* b)
{
    double distance = 0;
    for (int i = 0; i < 784; i++)
    {
        distance += pow(a->data[i] - b->data[i], 2);
    }
    return sqrt(distance);
}

void sort_vertices_by_Hamming_distance(std::vector<string>& sorted_vertex_vec, string starting_vertex, int probes)
{
    if (std::find(sorted_vertex_vec.begin(), sorted_vertex_vec.end(), starting_vertex) != sorted_vertex_vec.end())
        return;
    if (probes == 0)
        return;

    sorted_vertex_vec.push_back(starting_vertex);

    for (int i = 0; i < starting_vertex.size(); i++)
    {
        string temp_vertex = starting_vertex;
        if (temp_vertex[i] == '0')
            temp_vertex[i] = '1';
        else
            temp_vertex[i] = '0';

        sort_vertices_by_Hamming_distance(sorted_vertex_vec, temp_vertex, probes - 1);
    }
}

void exact_kNN(Image* img, vector<Image*>& data, PriorityQueueAscending& queue, int no_neigbours)
{
    for (int i = 0; i < data.size(); i++)
    {
        double distance = dist(img, data.at(i));
        queue.push_limited(data.at(i), distance);
    }
}

void approximate_kNN_LSH(Image* img, LSH& lsh, PriorityQueueAscending& queue, int no_neigbours)
{
    double min_distance = std::numeric_limits<double>::max();

    int points_checked = 0;
    for (int i = 0; i < lsh.hash_tables.size(); i++)
    {
        //find in which bucket it belongs
        std::pair<int, unsigned int> p1 = lsh.hash_tables.at(i).g_hash.hash_image(img);
        vector<Image*>& bucket_images = lsh.hash_tables.at(i).buckets.at(p1.first)->bucket_images;
        try
        {
            //calculate distance to all images in the bucket 
            for (int j = 0; j < bucket_images.size(); j++)
            {
                double distance = dist(img, bucket_images.at(j));
                queue.push_limited(bucket_images.at(j), distance);

                if (++points_checked > 10 * lsh.hash_tables.size())
                    break;
            }
            if (points_checked > 10 * lsh.hash_tables.size())
                break;
        }
        catch (std::out_of_range oor)
        {
            continue;
        }
    }
}

void approximate_range_search_LSH(Image* img, LSH& lsh, int radius, PriorityQueueAscending& queue)
{
    int points_checked = 0;

    for (int i = 0; i < lsh.hash_tables.size(); i++)
    {
        //find in which bucket it belongs
        std::pair<int, unsigned int> p1 = lsh.hash_tables.at(i).g_hash.hash_image(img);

        std::vector<Image*>& bucket_images = lsh.hash_tables.at(i).buckets.at(p1.first)->bucket_images;

        try
        {
            for (int j = 0; j < bucket_images.size(); j++)
            {
                double temp_distance = dist(bucket_images.at(j), img);
                //if within radius --> add it to priority queue
                if (temp_distance <= radius)
                    queue.push(bucket_images.at(j), temp_distance);

                if (++points_checked > 20 * lsh.hash_tables.size())
                    break;
            }
            if (points_checked > 20 * lsh.hash_tables.size())
                break;
        }
        catch (std::out_of_range oor)
        {
            continue;
        }
    }
}

void approximate_kNN_Hypercube(Image* img, int k, HyperCube hypercube,
    PriorityQueueAscending& queue, int probes, int M)
{
    double min_distance = std::numeric_limits<double>::max();
    int points_checked = 0;
    string vertex_index;
    std::vector<string> sorted_vertex_vec;

    //find image vertex
    for (int j = 0; j < k; j++)
        vertex_index += hypercube.projectors.at(j)->calc_zero_or_one(img);

    cout << "vertex_index=" << vertex_index << endl;

    try
    {
        //find adjacent vertices (within probes limit)
        sort_vertices_by_Hamming_distance(sorted_vertex_vec, vertex_index, probes);

        for (int jj = 0; jj < sorted_vertex_vec.size(); jj++)
        {
            for (int i = 0; i < hypercube.vertices.at(sorted_vertex_vec[jj])->bucket_images.size(); i++)
            {
                double temp_distance = dist(hypercube.vertices.at(sorted_vertex_vec[jj])->bucket_images.at(i), img);
                queue.push_limited(hypercube.vertices.at(sorted_vertex_vec[jj])->bucket_images.at(i), temp_distance);

                if (++points_checked > M)
                    break;
            }
            if (points_checked > M)
                break;
        }
    }
    catch (std::out_of_range oor)
    {

    }
}

void approximate_range_search_hypercube(Image* img, int k, HyperCube hypercube, int radius,
    PriorityQueueAscending& queue, int M, int probes)
{
    double min_distance = std::numeric_limits<double>::max();
    std::vector<string> sorted_vertex_vec;
    int points_checked = 0;
    string vertex_index;

    //find image vertex
    for (int j = 0; j < k; j++)
        vertex_index += hypercube.projectors.at(j)->calc_zero_or_one(img);

    cout << "vertex_index=" << vertex_index << endl;

    try
    {
        //find adjacent vertices (within probes limit)
        sort_vertices_by_Hamming_distance(sorted_vertex_vec, vertex_index, probes);

        for (int jj = 0; jj < sorted_vertex_vec.size(); jj++)
        {
            for (int i = 0; i < hypercube.vertices.at(sorted_vertex_vec[jj])->bucket_images.size(); i++)
            {
                double temp_distance = dist(hypercube.vertices.at(sorted_vertex_vec[jj])->bucket_images.at(i), img);
                if (temp_distance <= radius)
                    queue.push(hypercube.vertices.at(sorted_vertex_vec[jj])->bucket_images.at(i), temp_distance);

                if (++points_checked > M)
                    break;
            }
            if (points_checked > M)
                break;
        }
    }
    catch (std::out_of_range oor)
    {

    }
}

void GNNS_algorithm(Image* img, NNGraph &graph, PriorityQueueAscending &queue, int N)
{
    int T = 50; //greedy steps
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<int> uniform_dist(0, graph.data.size());
    vector<int> marked_ids;

    //for R random restarts
    for(int i = 0; i < graph.R; i++)
    {
        //at first, get random point Y
        int Y = uniform_dist(gen);
        int no_of_loops = 0; //loop until T
        double previous_Y_distance = std::numeric_limits<double>::max();
        while(true)
        {
            //find new Y
            double min_distance = std::numeric_limits<double>::max();
            int new_Y = -1;

            //get first E neighbors for graph's element Y
            int count = 0;
            for(int id : graph.lists.at(Y))
            {
                //find the closest of E neighbors to query
                double temp_distance = dist(img, graph.data.at(id));
                if(std::find(marked_ids.begin(), marked_ids.end(), id) == marked_ids.end())
                {
                    //add item in priority queue
                    queue.push_limited(graph.data.at(id), temp_distance);
                    //mark item as used
                    marked_ids.push_back(id);
                }

                //new Y selection
                if(temp_distance < min_distance)
                {
                    min_distance = temp_distance;
                    new_Y = id;
                }

                count++;
                if(count == graph.E)
                    break;
            }

            //if local minimum found-->break
            if(previous_Y_distance < min_distance)
                break;

            previous_Y_distance = min_distance;

            //if T loops performed -->break
            if(++no_of_loops > T)
                break;
        }
    }
}

void Search_on_Graph_algorithm(Image* img, vector<Image*> &data, MrnGraph &graph, PriorityQueueAscending &queue, int N, int l)
{
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<int> uniform_dist(0, data.size());

    vector<std::pair<int, bool>> candidates;
    int p = uniform_dist(gen);
    int i = 1;

    //init candidates
    candidates.push_back(std::pair<int, bool>(p, false));
    while(i < l)
    {
        int selected_p;
        for(int i = 0; i < candidates.size(); i++)
        {
            if(candidates.at(i).second == false)
            {
                selected_p = candidates.at(i).first;
                candidates.at(i).second = true;
                break;
            }
        }

        //for every neighbor N of p
        for(int neighbor : graph.neighbors_per_point.at(selected_p))
        {
            bool found = false;
            for(int j = 0; j < candidates.size(); j++)
            {
                if(candidates.at(j).first == neighbor)
                {
                    found = true;
                    break;
                }

            }
            if(found == false)
            {
                candidates.push_back(std::pair<int, bool>(neighbor, false));
                i++;
            }
        }

        //to get the first k sorted in ascending order
        for(std::pair<int, bool> items: candidates)
        {
            double distance = dist(img, data.at(items.first));
            queue.push_limited(data.at(items.first), distance);
        }
    }
}
