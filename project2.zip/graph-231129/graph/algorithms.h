#ifndef ALGORITHMS_H
#define ALGORITHMS_H
#include <vector>
#include <utility>
#include <cmath>
#include <queue>
#include <limits>
#include <algorithm>

#include "image.h"
#include "hashTable.h"
#include "f_Function.h"
#include "lsh.h"
#include "hyperCube.h"
#include "priorityQueue.h"
#include "nnGraph.h"
#include "mrnGraph.h"

double dist(Image* a, Image* b);

void sort_vertices_by_Hamming_distance(std::vector<string>& sorted_vertex_vec, string starting_vertex, int probes);

void exact_kNN(Image* img, vector<Image*>& data, PriorityQueueAscending& queue, int no_neigbours);

void approximate_kNN_LSH(Image* img, LSH& lsh, PriorityQueueAscending& queue, int no_neigbours);

void approximate_range_search_LSH(Image* img, LSH& lsh, int radius, PriorityQueueAscending& queue);

void approximate_kNN_Hypercube(Image* img, int k, HyperCube hypercube, PriorityQueueAscending& queue, int probes, int M);

void approximate_range_search_hypercube(Image* img, int k, HyperCube hypercube, int radius,
    PriorityQueueAscending& queue, int M, int probes);

void GNNS_algorithm(Image* img, NNGraph &graph, PriorityQueueAscending &queue_approx, int N);    

void Search_on_Graph_algorithm(Image* img, vector<Image*> &data, MrnGraph &graph, PriorityQueueAscending &queue, int N, int l);

#endif //ALGORITHMS_H