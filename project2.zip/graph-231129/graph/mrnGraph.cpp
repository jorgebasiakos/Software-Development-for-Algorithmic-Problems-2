#include "mrnGraph.h"
#include <list>
#include "image.h"
#include "priorityQueue.h"
#include "algorithms.h"

MrnGraph::MrnGraph(std::vector<Image*>* _data, LSH *lsh, int _l, int _N)
{
    data = _data;
    l = _l;
    N = _N;

    cout << "starting building MRNG" << endl;

    for(int p = 0; p < data->size(); p++)
    {
        if(p % 1000 == 0)
            std:cout << p << " " ;
            std::cout.flush();

        PriorityQueueAscending queue(data->size());
        list<int> neighbors;
        
        // use LSH to get the sorted neighbors
        approximate_kNN_LSH(data->at(p), *lsh, queue, data->size());

        //the first ones may be the same point->remove them
        while(queue.top().img->id == p)
            queue.pop();

        //initialize Lp
        neighbors.push_back(queue.top().img->id);
        queue.pop();

        bool condition = true;
        int r;
        for(int i = 0; i < queue.size(); i++)
        {
            for(int t = 0; t < neighbors.size(); t++)
            {
                r = queue.top().img->id;
                queue.pop();

                //if pr > pt and pr > rt
                if(dist(data->at(p), data->at(r)) > dist(data->at(p), data->at(t))
                 && dist(data->at(p), data->at(r)) > dist(data->at(r), data->at(t)))  
                 {
                    condition = false;
                    break;
                 }
            }

            if(condition == true && r != p)
            {
                neighbors.push_back(r);
            }

            condition = true;
        }

        neighbors_per_point.insert(std::pair<int, list<int>>(p, neighbors));        
    }
}