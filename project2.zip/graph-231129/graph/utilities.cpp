#include "utilities.h"

Arguments::Arguments()
{
    char* input_file_name = nullptr;
    char* query_file_name = nullptr;
    char* output_file_name = nullptr;
    char* conf_file_name = nullptr;
    int k = 0;
    int L = 0;
    int N = 0;
    int R = 0;
    int M = 0; //cube
    int probes = 0; //cube
    char* complete = (char*)"false"; //cluster
    char* method = (char*)"Classic"; //cluster

    //cluster.conf
    int number_of_clusters = 0;
    int number_of_vector_hash_tables = 0;
    int number_of_vector_hash_functions = 0;
    int max_number_M_hypercube = 0;
    int number_of_hypercube_dimensions = 0;
    int number_of_probes = 0;
}

bool Arguments::parse_arguments_lsh(int argc, char* argv[])
{
    try
    {
        for(int i = 1; i < argc; i+=2)
        {
            if(strcmp(argv[i], "-d") == 0)
                input_file_name = argv[i+1];
            else if(strcmp(argv[i], "-q") == 0)
                query_file_name = argv[i+1];
            else if(strcmp(argv[i], "-k") == 0)
                k = atoi(argv[i+1]);
            else if(strcmp(argv[i], "-L") == 0)
                L = atoi(argv[i+1]);
            else if(strcmp(argv[i], "-o") == 0)
                output_file_name = argv[i+1];
            else if(strcmp(argv[i], "-N") == 0)
                N = atoi(argv[i+1]);
            else if(strcmp(argv[i], "-R") == 0)
                R = atoi(argv[i+1]);
            else
                return false;
        }
    }
    catch(exception ex)
    {
        return false;
    }
    if(strlen(input_file_name) == 0 
        || strlen(query_file_name) == 0
        || strlen(output_file_name) == 0)
        return false;

    return true;
}

bool Arguments::parse_arguments_cube(int argc, char* argv[])
{
    try
    {
        for(int i = 1; i < argc; i+=2)
        {
            if(strcmp(argv[i], "-d") == 0)
                input_file_name = argv[i+1];
            else if(strcmp(argv[i], "-q") == 0)
                query_file_name = argv[i+1];
            else if(strcmp(argv[i], "-k") == 0)
                k = atoi(argv[i+1]);
            else if(strcmp(argv[i], "-M") == 0)
                M = atoi(argv[i+1]);
            else if(strcmp(argv[i], "-probes") == 0)
                probes = atoi(argv[i+1]);
            else if(strcmp(argv[i], "-o") == 0)
                output_file_name = argv[i+1];
            else if(strcmp(argv[i], "-N") == 0)
                N = atoi(argv[i+1]);
            else if(strcmp(argv[i], "-R") == 0)
                R = atoi(argv[i+1]);
            else
                return false;
        }
    }
    catch(exception ex)
    {
        return false;
    }
    if(strlen(input_file_name) == 0 
        || strlen(query_file_name) == 0
        || strlen(output_file_name) == 0)
        return false;

    return true;
}

bool Arguments::parse_arguments_cluster(int argc, char* argv[])
{
    try
    {
        for(int i = 1; i < argc; i+=2)
        {
            if(strcmp(argv[i], "-i") == 0)
                input_file_name = argv[i+1];
            else if(strcmp(argv[i], "-c") == 0)
                conf_file_name = argv[i+1];
            else if(strcmp(argv[i], "-o") == 0)
                output_file_name = argv[i+1];
            else if(strcmp(argv[i], "-complete") == 0)
                complete = argv[i+1];
            else if(strcmp(argv[i], "-m") == 0)
                method = argv[i+1];
            else
                return false;
        }
    }
    catch(exception ex)
    {
        return false;
    }
    if(strlen(input_file_name) == 0 
        || strlen(conf_file_name) == 0
        || strlen(output_file_name) == 0)
        return false;

    return true;
}

bool Arguments::parse_arguments_graph(int argc, char* argv[])
{
    try
    {
        for(int i = 1; i < argc; i+=2)
        {
            if(strcmp(argv[i], "-d") == 0)
                input_file_name = argv[i+1];
            else if(strcmp(argv[i], "-q") == 0)
                query_file_name = argv[i+1];
            else if(strcmp(argv[i], "-k") == 0)
                k = atoi(argv[i+1]);
            else if(strcmp(argv[i], "-E") == 0)
                E = atoi(argv[i+1]);
            else if(strcmp(argv[i], "-R") == 0)
                R = atoi(argv[i+1]);
            else if(strcmp(argv[i], "-N") == 0)
                N = atoi(argv[i+1]);
            else if(strcmp(argv[i], "-l") == 0)
                l = atoi(argv[i+1]);
            else if(strcmp(argv[i], "-m") == 0)
                m = atoi(argv[i+1]);
            else if(strcmp(argv[i], "-o") == 0)
                output_file_name = argv[i+1];
            else
            {
                return false;
            }
        }
    }
    catch(exception ex)
    {
        return false;
    }
    // if(strlen(input_file_name) == 0 
    //     || strlen(query_file_name) == 0
    //     || strlen(output_file_name) == 0)
    //     return false;

    return true;
}

bool Arguments::parse_conf_file(char* conf_file_name)
{
    string line;
    std::ifstream ifs(conf_file_name);
    try
    {
        while(std::getline(ifs, line))
        {
            size_t i = line.find(":");
            string param_name = line.substr(0, i);
            string param_value = line.substr(i+1, line.length());

            if(param_name == "number_of_clusters")
                number_of_clusters = std::stoi(param_value);
            else if(param_name == "number_of_vector_hash_tables")
                number_of_vector_hash_tables = std::stoi(param_value);
            else if(param_name == "number_of_vector_hash_functions")
                number_of_vector_hash_functions = std::stoi(param_value);
            else if(param_name == "max_number_M_hypercube")
                max_number_M_hypercube = std::stoi(param_value);
            else if(param_name == "number_of_hypercube_dimensions")
                number_of_hypercube_dimensions = std::stoi(param_value);
            else if(param_name == "number_of_probes")
                number_of_probes = std::stoi(param_value);
            else
                return false;
        }
    }
    catch(const std::exception& e)
    {
        return false;
    }
    
    return true;
}

void Arguments::print_arguments()
{
    std::cout << "input: " << input_file_name << endl;
    std::cout << "query: " << query_file_name << endl;
    std::cout << "output: " << output_file_name << endl;
    std::cout << "k: " << k << endl;
    std::cout << "L: " << L << endl;
    std::cout << "N: " << N << endl;
    std::cout << "R: " << R << endl;
    std::cout << "M: " << M << endl;
    std::cout << "probes: " << probes << endl;
    std::cout << "complete: " << complete << endl;
    std::cout << "method: " << method << endl;
}

void read_images(std::ifstream& ifs, std::vector<Image*>& data, int& img_no, int& row_no, int& col_no)
{
    if (ifs)
    {
        unsigned char buffer[4];
        ifs.read(reinterpret_cast<char*>(buffer), 4);

        ifs.read(reinterpret_cast<char*>(buffer), 4);
        img_no = (int)buffer[3] | (int)buffer[2] << 8 | (int)buffer[1] << 16 | (int)buffer[0] << 24;

        ifs.read(reinterpret_cast<char*>(buffer), 4);
        row_no = (int)buffer[3] | (int)buffer[2] << 8 | (int)buffer[1] << 16 | (int)buffer[0] << 24;

        ifs.read(reinterpret_cast<char*>(buffer), 4);
        col_no = (int)buffer[3] | (int)buffer[2] << 8 | (int)buffer[1] << 16 | (int)buffer[0] << 24;

        unsigned char* buf = new unsigned char[row_no * col_no];
        int id = 0;

        int count = 0;
        while (ifs.read(reinterpret_cast<char*>(buf), row_no * col_no))
        {
            Image* img = new Image(buf, id++);
            data.push_back(img);

            // if(++count == 100)
            // {
            //     img_no = 100;
            //     break;
            // }
        }

        ifs.close();

        std::cout << "Total images: " << data.size() << endl;
    }
}


void read_query_images(std::ifstream& ifs, std::vector<Image*>& data, int row_no, int col_no)
{
    cout << "Reading query image" << endl;
    if (ifs)
    {
        unsigned char* buf = new unsigned char[row_no * col_no];
        int id = 0;
        while (ifs.read(reinterpret_cast<char*>(buf), row_no * col_no))
        {
            Image* img = new Image(buf, id++);
            data.push_back(img);
        }

        ifs.close();

        std::cout << "Total query images: " << data.size() << endl;
    }
}